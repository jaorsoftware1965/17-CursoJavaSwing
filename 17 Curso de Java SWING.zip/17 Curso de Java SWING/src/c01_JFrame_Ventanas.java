import javax.swing.JFrame;
import java.awt.Frame;
import java.awt.Graphics;


// Definimos nuestra propia clase de Ventana
class myWindow extends JFrame
{
    // Constructor
	public myWindow()
    {
		// Llama al Constructor con el Título de la Ventana
        super("Hola Mundo con ventanas");

        // Establece el Tamaño
        setSize(500,500);// Ancho y Alto
        
        
        // La ubica
        setLocation(100, 200); // x,y

        // La maximiza, solo funciona cuando ya está visible
        //setExtendedState(Frame.MAXIMIZED_BOTH);
        
        // Centra la Ventana
        //this.setLocationRelativeTo(getParent()); // Centra en base a su Ventana Padre si tiene
        setLocationRelativeTo(null); // Centra en base a la Ventana
       
        // La hace Visible
        setVisible(true);
       
    }
    
	// Re-escribe el Método paint
    public void paint(Graphics g)
    {
    	// Dibuja un Mensaje en la Ventana
        g.drawString("Mi primer Ventana en JAVA",160,160);
       
    }
}

public class c01_JFrame_Ventanas 
{
	
    public static void main(String[] args) 
    {
        // Clase 01 - jFrame_Ventanas
        // El elemento principal en cualquier Sistema Operativo Gráfico, es la ventana 
    	// (window); tambien llamada marco (frame)
        // Todo lo que exista en una aplicación gráfica es una ventana; aunque no todas 
    	// las ventanas son iguales
        // Un combobox es una ventana; un botón es una ventana; solo que tienen diferentes 
    	// características
        // En java existen 2 librerías para manejar objetos gráficos:AWT-Abstract Window 
    	// Toolkit y Swing el cual está apoyado en AWT; así que si usamos Swing en cierta 
    	// forma estamos usando AWT.
     
    	// La Clase que utilizaremos para crear nuestra primera ventana es: JFrame
        
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindow xWindow = new myWindow();
    }
}
