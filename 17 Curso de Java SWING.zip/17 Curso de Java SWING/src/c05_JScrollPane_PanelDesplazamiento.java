import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

//Definimos nuestra propia clase de Ventana
class myWindowScrollPane extends JFrame
{
	private JLabel      lblUsuario,lblClave,lblComentarios;
	private JTextField  txtUsuario, txtClave;
	private JTextArea   txtArea1;
	private JScrollPane pnlComentarios;
	
	public myWindowScrollPane() 
	{
	 	// Coloca el Titulo
	 	setTitle("Clase05_JScrollPane");
		
	 	// Establece la acción a realizar cuando se cierra la forma
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	 	// Establece que no existe un Layout
	    setLayout(null);
	     
	    // Crea las Etiquetas de Usuario y Clave
	    lblUsuario=new JLabel("Usuario:");
	    lblUsuario.setBounds(10,20,300,30);
	    lblClave=new JLabel("Clave:");
	    lblClave.setBounds(10,70,300,30);
	
	    // Añade las etiquetas a la Ventana
	    add(lblUsuario);
	    add(lblClave);
	     
	    // Crea los campos de texto de Usuario y Clave
	    txtUsuario=new JTextField("Capture Usuario:");
	    txtUsuario.setBounds(120,20,300,30);
	    txtClave=new JTextField("Capture Clave:");
	    txtClave.setBounds(120,70,300,30);
	
	    // Añade las etiquetas a la Ventana
	    add(txtUsuario);
	    add(txtClave);
	
	    // Crea la Etiqueta del Comentario
	    lblComentarios=new JLabel("Comentarios:");
	    lblComentarios.setBounds(10,120,300,30);
	    add(lblComentarios);
	
	    // Crea el área de Texto
	    txtArea1=new JTextArea();
		//txtArea1.setBounds(100,1500,810,300);
		// Lo hace no editable; Esto puede usarse en otros controles
		//txtArea1.setEditable(false);	
		
		// Le coloca un borde
		txtArea1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	
		// Crea al Panel de Control y al mismo tiempo agrega el area de texto
	    pnlComentarios=new JScrollPane(txtArea1);    
	    pnlComentarios.setBounds(10,150,410,300);
	    add(pnlComentarios);    
	    
	    // Lo habilita deshabilita
	    //pnlComentarios.show(false);
	    //pnlComentarios.show(true);
	    //pnlComentarios.hide();
	 
	}

}

public class c05_JScrollPane_PanelDesplazamiento {

	public static void main(String[] args) {
        // Clase 05 - JScrollPane_PanelDesplazamiento
		// 
		// Un panel de desplazamiento, es un control que define un área en la
		// cual si existe información que desborde el área definida del control,
		// muestra una barra de desplazamiento horizontal y una vertical segun
		// sea el caso del desborde
		
        // La Clase que se utiliza para crear un área de desplazamiento es JScrollPane
				
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowScrollPane xWindow = new myWindowScrollPane();

    	//Establecemos la posición (100,100) y el tamaño (430,500) de la Ventana
    	xWindow.setBounds(100,100,440,500);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);
    	
    }

}
