import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

//Definimos nuestra propia clase de Ventana
class myWindowPanel extends JFrame
{
	// Botones para utilizar
	private JButton btnUno, btnDos, btnTres, btnCuatro, btnCinco;
	
	// Panel de Distriución
	JPanel pnlBotones;
	
	 public myWindowPanel() 
	 {
	
		// Coloca el Titulo
	 	setTitle("Clase 09 JPanel");
	 	 	
	    // Establece la acción a realizar cuando se cierra la forma
	 	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 	
	  	// Establece que no existe un Layout
	    setLayout(null);
	          	   
	    // Crea los botones
	    btnUno     = new JButton("Uno");
	    btnDos     = new JButton("2");
	    btnTres    = new JButton("Tres");
	    btnCuatro  = new JButton("IV");
	    btnCinco   = new JButton("Cinco");
	    
	    // Dimensiona los Botones
	    btnUno.setBounds(10, 10, 50, 50);
	    btnDos.setBounds(10, 70, 50, 50);
	    btnTres.setBounds(10, 130, 50, 50);
	    btnCuatro.setBounds(10, 190, 50, 50);
	    btnCinco.setBounds(10, 230, 50, 50);
	    
	    
	    // Crea al Panel
	    pnlBotones = new JPanel();
	
	    // Establecemos el Layout a null
	    //pnlBotones.setLayout(null);
	    pnlBotones.setLayout(new FlowLayout());//FlowLayout.LEADING,FlowLayout.CENTER, or FlowLayout.TRAILING
	    
	    
	    // GridLayout(int rows, int cols)
	    //pnlBotones.setLayout(new GridLayout(4,2));
	    	    
	    // Establecemos el Borde 
	    pnlBotones.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	    
	    // Establece posición y tamaño del Panel
	    pnlBotones.setBounds(10,10,180,180);
	    	
	    // Agrega la etiqueta y la lista al Panel
	    pnlBotones.add(btnUno);
	    pnlBotones.add(btnDos);
	    pnlBotones.add(btnTres);
	    pnlBotones.add(btnCuatro);
	    pnlBotones.add(btnCinco);
	    
	    // Añade el Panel a la Forma
	    add(pnlBotones);
	    
	 }

}

public class c09_JPanel {
	public static void main(String[] args) {
        // Clase 09 - JPanel
		
		// Un elemento JPanel, es un contenedor con la finalidad de agrupar otros
	 	// objetos en el. Es utilizado mayormente cuando se necesita tener una 
	 	// distribución de objetos específica, la cual se realiza a través de
	 	// Layouts. La Clase que se utiliza para este objeto es JPanel
		
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowPanel xWindow = new myWindowPanel();

    	//Establecemos la posición (100,100) y el tamaño (430,500) de la Ventana
    	xWindow.setBounds(100,100,200,200);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	//La maximiza
    	xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }
}