import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.JButton;
import javax.swing.JFrame;

//Definimos nuestra propia clase de Ventana
class myWindowButton extends JFrame
{
	// Declara 2 Botones
	JButton btnAceptar, btnCancelar;
	
	public myWindowButton() 
	{
		// Coloca el Titulo
		setTitle("Clase 08 JButton");
		 	
  	    // Establece la acción a realizar cuando se cierra la forma
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Establece que no existe un Layout
	    setLayout(null);	         
	    
	    // Crea el Botón
	    btnAceptar = new JButton("Aceptar");
        
	    // Establece posición y tamaño
	    btnAceptar.setBounds(30,310,100,30);
	    
    	// Crea el Botón
	    btnCancelar = new JButton("Cancelar");
        
	    // Establece posición y tamaña
	    btnCancelar.setBounds(270,310,100,30);
	    
        
	    // Agrega el Botón
	    add(btnAceptar);
	    add(btnCancelar);
	    
	    // Modificando la Fuente y el Color
	    btnAceptar.setForeground(Color.BLUE);
	    btnCancelar.setBackground(Color.RED);
	    
	    // Creamos una nueva fuente
        Font font = new Font("Courier", Font.ITALIC | Font.BOLD,14);

        // Establecemos la fuente
        btnAceptar.setFont(font);
	}
}

public class c08_JButton 
{
	public static void main(String[] args) 
	{
        // Clase 08 - JButton
		
		// Un elemento JButton, es tal y como lo indica su nombre, un objeto
		// que simula un botón el cual puede ser presionado para ejecutar
		// una acción específica.
		
		// La Clase que se utiliza para este objeto es JButton
		
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowButton xWindow = new myWindowButton();

    	// Establecemos la posición y tamaño
    	xWindow.setBounds(100,100,400,400);
    	
    	// La Centra
    	xWindow.setLocationRelativeTo(null);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

	}
}
