import java.awt.GridLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

//Definimos nuestra propia clase de Ventana
class myWindowGridLayout extends JFrame
{
	// Controles a agregar a la Forma
	Label  lblUno    =  new Label("Uno");
	Label  lblDos    =  new Label("Dos");
	Label  lblTres   =  new Label("Tres"); 
	Label  lblCuatro =  new Label("Cuatro"); 
	Label  lblCinco  =  new Label("Cinco");	
	Button btnSeis   =  new Button("Seis");     
	 
	// Constructor
	public myWindowGridLayout() 	
	{
		
		
		// Establece el T�tulo de la Clase
		super("Clase 44_GridLayout");
		
		// Coloca el GridLayout; si no se indica el Grid ser� de un rengl�n
		// y colocar� una columna por cada dato que se agregue
		//setLayout(new GridLayout());
		
		// Grid con 2 Renglones y 3 Columnas
		setLayout(new GridLayout(2,3));
		
        // Se agregan los controles
		add(lblUno);
		add(lblDos);
		add(lblTres);
		add(lblCuatro);
		add(lblCinco);
		add(btnSeis);
		// EL Siguiente no lo pone al centro exactamente
		//add(btnSeis,FlowLayout.CENTER);
		// Lo coloca a la izquierda de los que haya puesto antes
		//add(btnSeis,FlowLayout.LEFT);
		
		// Usar la siguiente instrucci�n en caso de no haber indicado el tam�o de la
		// ventana, para que se realice el ajuste de acuerdo al Layout
		pack(); 
				
		// Lo hace visible
		this.setVisible(true);        
		 
	 }

}

public class c16_GridLayout {
	public static void main(String[] args) {
        // Clase 44 - GridLayout
		
		// Para esta clase veremos el GridLayout, el cual permite organizar los 
		// controles dentro de un Grid en columnas y renglones con celdas de
		// tama�o fijo.
		// La clase que utiliza es GridLayout

		// Creamos el Objeto de la Forma
    	myWindowGridLayout xWindow = new myWindowGridLayout();


    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	// Define el Tama�o
    	xWindow.setSize(400, 400);
    	
    	//La maximiza
    	//xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }


}
