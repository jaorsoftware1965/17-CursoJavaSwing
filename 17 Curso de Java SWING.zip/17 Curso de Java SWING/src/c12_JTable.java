import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

//Definimos nuestra propia clase de Ventana
class myWindowTable extends JFrame
{
	 
	// Constructor
	public myWindowTable() 	
	{
		
		// Establece el Título de la Clase
		super("Clase 12 JTable");
		
		// Variable para poder modificar datos de la tabla
		DefaultTableModel dtmCalendario;
		TableModel tbmCalendario;

		// Establece el Layout
		setLayout(null);

		//Matriz de Datos para la Tabla
	    Object[][] matDatos = 
	        	{
	        		{"", "", "", "", "","", ""},
	        		{"", "", "", "", "","", ""},
	        		{"", "", "", "", "","", ""},
	        		{"", "", "", "", "","", ""},
	        		{"", "", "", "", "","", ""},
	        		{"", "", "", "", "","", ""}
	        };
	        
        //Array de Títulos de las columnas
        String[] arrTitulos = {"Dom", "Lun", "Mar","Mie", "Jue","Vie","Sab"};
        
        // Coloco el Modelo en la tabla del Calendario
        JTable tblCalendario = new JTable(matDatos,arrTitulos);        
        tblCalendario.setCellSelectionEnabled(true);
        
        //Creamos un JscrollPane y le agregamos la JTable
		JScrollPane pnlCalendario = new JScrollPane(tblCalendario);

		// Establecemos posición y tamaño del Panel
		pnlCalendario.setBounds(0, 0, 400, 150);
		 
		//Agregamos el JScrollPane al contenedor
		//getContentPane().add(pnlCalendario, BorderLayout.CENTER);
		add(pnlCalendario, BorderLayout.CENTER);
		
		// Obtenemos el modelo de la Tabla
		tbmCalendario = tblCalendario.getModel();
		
		// Ahora podemos modificar información una vez teniendo el modelo
		// Colocar valores
		tbmCalendario.setValueAt("Hoy", 1, 1); 
		tbmCalendario.setValueAt(123, 1, 2);
		
		// Obtener Valores
		System.out.println("Valor de 1,1:"+tbmCalendario.getValueAt(1, 1));    

		// Obtener Numero de Columnas
		System.out.println("Columnas:"+tbmCalendario.getColumnCount());    
		
		// Obtener Numero de Renglones
		System.out.println("Renglones:"+tbmCalendario.getRowCount());   
		
		// Obtener Nombre de Columnas
		System.out.println("Nombre de Columna 6:"+tbmCalendario.getColumnName(6));   
		
		// Pero no nos permite hacer otras cosas como agregar columna, 
		// Para lo cual utilizaremos el DefaulTableModel
	    dtmCalendario = new DefaultTableModel(matDatos,arrTitulos);
	    
	    // Colocamos el modelo en el JTable
	    tblCalendario.setModel(dtmCalendario);
	    
	    // Ahora manipulamos el DefaultTableModel
	    dtmCalendario.addColumn("Extra");
	    
	    // Eliminamos una Columna con esta instrucción
	    dtmCalendario.setColumnCount(6);
	    
   	    // Agregamos Columnas con esta instrucción
	    dtmCalendario.setColumnCount(8);
	    
	    // Agregamos un Renglon
	    Object[] newRow={"Lun","Mar","Mie","Jue","Vie","Sab","Ex1","Ex2"};
	    dtmCalendario.addRow(newRow);
	    
	    // Establecer Valores
	    dtmCalendario.setValueAt(7, 2,2);
	    
	    // MOdifcar las columnas colocando el Último Renglon
	    dtmCalendario.setColumnIdentifiers(newRow);
		
		// Lo hace visible
		this.setVisible(true);
	 }
}

public class c12_JTable {
	public static void main(String[] args) 
	{
        // Clase 12 - JTable
		
		// El JTable es un control que nos permite manejar información 
		// distribuida en celdas, a las cuales se puede acceder por medio
		// de renglones y columnas. Tambien es conocido en otros lenguajes
		// como grid o rejilla
		
		// La Clase que permite crear estos controles es la clase JTable

		// Para que el control JTable muestre las columnas establecidas, debe
		// de encontrarse dentro de JScrollPanel; de otra forma no lo hará.
		// Para poder eliminar, agregar o modificar elementos de la tabla,
		// deberemos de hacer uso de la Clase DefaultTableModel

		// Declaramos un objeto de nuestra Clase myWindow        
    	myWindowTable xWindow = new myWindowTable();

    	//Establecemos la posición (100,100) y el tamaño (430,500) de la Ventana
    	xWindow.setBounds(100,100,440,500);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);
   	
    }
}
