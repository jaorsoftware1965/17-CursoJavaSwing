import java.awt.Frame;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

//Definimos nuestra propia clase de Ventana
class myWindowMenu extends JFrame
{
	// Propiedades para el Menu
	private JMenuBar  mbPrincipal;
    private JMenu     mnuSistema,mnuXtra;
    private JMenuItem opcEntrada,opcSalida,opcConfiguracion,opcXtra1,opcXtra2;
    
	 
	// Constructor
	public myWindowMenu() 	
	{
		
		
		// Establece el Título de la Clase
		super("Clase 13 Menu");
		
		// Establece el Layout
		setLayout(null);

		// Creamos primeramente la Barra del Menu
		mbPrincipal =new JMenuBar();
		
		// Colocamos la Barra en la Ventana
        setJMenuBar(mbPrincipal);
        
        // Creamos el Menu Sistema
        mnuSistema=new JMenu("Sistema");
        
        // Añadimos el Menu a la Barra
        mbPrincipal.add(mnuSistema);
        
        // Creamos las opciones Entrada y la agregamos al Menu Sistema 
        opcEntrada=new JMenuItem("Entrada");
        mnuSistema.add(opcEntrada);

        // Creamos las opciones Salida y la agregamos al Menu Sistema 
        opcSalida=new JMenuItem("Salida");
        mnuSistema.add(opcSalida);
        
        // Creamos las opciones Configuración y la agregamos al Menu Sistema 
        opcConfiguracion=new JMenuItem("Configuracion");
        mnuSistema.add(opcConfiguracion);  
        
        // Agregamos un Separador
        mnuSistema.add(new JSeparator()); 
        
        // Creamos el Menu Extra y lo agregamos al Menu Sistema
        mnuXtra=new JMenu("Extra");
        mnuSistema.add(mnuXtra);
        
        // Creamos las opciones Xtra y las agregamos al Menu Xtra 
        opcXtra1=new JMenuItem("Xtra1");
        mnuXtra.add(opcXtra1);
        opcXtra2=new JMenuItem("Xtra2");
        mnuXtra.add(opcXtra2);

        // Agregar un Acelerador
        KeyStroke f5 = KeyStroke.getKeyStroke(KeyEvent.VK_F5,KeyEvent.SHIFT_DOWN_MASK);
        KeyStroke keyEscape = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,KeyEvent.CTRL_DOWN_MASK);
        opcXtra1.setAccelerator(f5);
        opcXtra2.setAccelerator(keyEscape);
        
		// Lo hace visible
		this.setVisible(true);
		
        
		 
	 }

}

public class c13_JMenu {
	public static void main(String[] args) {
        // Clase 41 - Menu's
		
		// Uno de los controles mas importantes y quiz�s imprecindible es una
		// aplicaci�n son los Men�es.
		// Para dise�ar un Menu en Java es necesario utilizar 3 clases en java
		// JMenuBar, JMenu, JMenuItem y JSeparator
		
		// El JMenuBar es una barra horizontal en la cual se colocar�n las
		// opciones principales del Men�.
		// JMenu es un control que contiene una opci�n del Men� y que se
		// agrega al JMenuBar para su despligue. Tambien es posible agregarlo
		// dentro de otro JMenu.
		
		// JMenuItem Es una subopci�n del JMenu la cual el usuario elige.
		
		// JSeparator es una clase que permite agregar una l�nea de separaci�n
		// entre las diferentes opciones del Menu
		

		// Creamos el Objeto de la Forma
    	myWindowMenu xWindow = new myWindowMenu();

    	//Establecemos la posici�n (100,100) y el tama�o (430,500) de la Ventana
    	//xWindow.setBounds(100,100,440,500);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	//La maximiza
    	xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }


}
