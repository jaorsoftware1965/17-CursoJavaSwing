import java.awt.GridLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

//Definimos nuestra propia clase de Ventana
class myWindowEventII extends JFrame implements KeyListener
{
	// Controles a agregar a la Forma
	private int numeroEvento = 1;
	private JTextField txtEntrada;
	 
	// Constructor
	public myWindowEventII() 	
	{		
		
		// Establece el T�tulo de la Clase
		super("Clase 46_EventosII");
		this.setLayout(null);

		// Construimos la interfaz
		txtEntrada = new JTextField();
		txtEntrada.setBounds(0,0,100,25);
		txtEntrada.addKeyListener(this);
		add(txtEntrada);
		setSize(400,600);
		setVisible(true);			
		
		
		
	 }
	
	public void keyTyped(KeyEvent e)
	{
	   System.out.println("Key"+e.getKeyChar());
	}
	public void keyReleased(KeyEvent e)
	{
		System.out.println("Key"+e.getKeyChar());
	}
	public void keyPressed(KeyEvent e)
	{
		System.out.println("KeyPressed"+e.getKeyChar());
	}
	
		
}

public class c18_EventosII {
	public static void main(String[] args) {
        // Clase 45 - Eventos
		

		// Creamos el Objeto de la Forma
    	myWindowEventII xWindow = new myWindowEventII();
    	
    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	// Define el Tama�o
    	xWindow.setSize(400, 400);
    	
    	//La maximiza
    	//xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }


}
