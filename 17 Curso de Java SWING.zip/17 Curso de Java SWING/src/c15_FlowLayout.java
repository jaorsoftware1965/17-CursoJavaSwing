import java.awt.FlowLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

//Definimos nuestra propia clase de Ventana
class myWindowFlowLayout extends JFrame
{
	// Controles a agregar a la Forma
	Label  lblUno    =  new Label("Uno");
	Label  lblDos    =  new Label("Dos");
	Label  lblTres   =  new Label("Tres"); 
	Label  lblCuatro =  new Label("Cuatro"); 
	Label  lblCinco  =  new Label("Cinco");	
	Button btnSeis   =  new Button("Seis");     
	 
	// Constructor
	public myWindowFlowLayout() 	
	{
		
		
		// Establece el T�tulo de la Clase
		super("Clase 43_FlowLayout");
		
		// Coloca el BorderLayout
		setLayout(new FlowLayout());

		// A�ade los controles uno a uno
		// Dependiendo del tama�o de la Ventana
		// se mover�n a la izquierda cuando se
		// haya terminado

		add(lblUno);
		add(lblDos);
		add(lblTres);
		add(lblCuatro);
		add(lblCinco);
		add(btnSeis);
		// EL Siguiente no lo pone al centro exactamente
		//add(btnSeis,FlowLayout.CENTER);
		// Lo coloca a la izquierda de los que haya puesto antes
		//add(btnSeis,FlowLayout.LEFT);
		
		// Usar la siguiente instrucci�n en caso de no haber indicado el tam�o de la
		// ventana, para que se realice el ajuste de acuerdo al Layout
		pack(); 
				
		// Lo hace visible
		this.setVisible(true);        
		 
	 }

}

public class c15_FlowLayout {
	public static void main(String[] args) {
        // Clase 43 - FlowLayout
		
		// Para esta clase veremos el FlowLayout, el cual permite organizar los 
		// controles de derecha a izquierda, hasta que se termina la pantalla
		// y entonces el siguiente controlo lo coloca en la siguiente L�nea
		// La clase que utiliza es FlowLayout

		// Creamos el Objeto de la Forma
    	myWindowFlowLayout xWindow = new myWindowFlowLayout();


    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	// Define el Tama�o
    	xWindow.setSize(400, 400);
    	
    	//La maximiza
    	//xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }


}
