import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

//Definimos nuestra propia clase de Ventana
class myWindowRadioButton extends JFrame
{
	private JRadioButton rbtVisualBasic,rbtVisualC,rbtJava;
    private ButtonGroup bg;
	 
	// Constructor
	public myWindowRadioButton() 	
	{
		// Establece el Título de la Clase
		super("Clase 11 RadioButton");

		// Establece el Layout
		setLayout(null);
		
		// Crea el Botón de Grupo
        bg=new ButtonGroup();

        // Crea cada uno de los RadioButton
        
        // Visual Basic
        rbtVisualBasic=new JRadioButton("Visual Basic");
        rbtVisualBasic.setBounds(10,20,200,30);
        add(rbtVisualBasic);
        bg.add(rbtVisualBasic);
        
        // Visual C++        
        rbtVisualC=new JRadioButton("Visual C++");
        rbtVisualC.setBounds(10,70,200,30);       
        add(rbtVisualC);
        bg.add(rbtVisualC);

        // Java
        rbtJava=new JRadioButton("Java");
        rbtJava.setBounds(10,120,200,30);       
        add(rbtJava);
        bg.add(rbtJava);        
        		 
	 }

}

public class c11_JRadioButton {
	public static void main(String[] args) {
        // Clase 11 - JRadioButton
		
		// El JRadioButton es un control que nos permite seleccionar una
		// sola opción entre varias.		
		// La Clase que permite crear estos controles es la clase JRadioButton
		// Para que este control funcione correctamente hace uso de otro
		// control llamado buttongroup, el cual permite agruparlos para que
		// solo pueda seleccionarse 1 de ellos; si no se estableciera así,
		// funcionaría como un checkbox
		// La Clase que pemite crear este control es JRadioButton
		
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowRadioButton xWindow = new myWindowRadioButton();

    	//Establecemos la posición (100,100) y el tamaño (430,500) de la Ventana
    	xWindow.setBounds(100,100,440,500);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	//La maximiza
    	xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }
}
