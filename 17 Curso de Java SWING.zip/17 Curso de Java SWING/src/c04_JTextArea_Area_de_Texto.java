import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

//Definimos nuestra propia clase de Ventana
class myWindowTextArea extends JFrame
{
	 // Elementos Privados
 	 private JLabel     lblUsuario,lblClave,lblComentarios; // Etiquetas
 	 private JTextField txtUsuario, txtClave;               // Campos de texto
 	 private JTextArea  txtArea1;                           // Text Area
	
	 // Constructor de la Clase
	 public myWindowTextArea() 
	 {
	 	// Coloca el Titulo
	 	setTitle("Clase 04 JTextArea Área de Texto");
		
	 	// Establece la acción a realizar cuando se cierra la forma
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
	 	// Establece que no existe un Layout
	    setLayout(null);
	     
	    // Crea las Etiquetas de Usuario y Clave
	    lblUsuario=new JLabel("Usuario:");
	    lblUsuario.setBounds(10,20,300,30);
	    lblClave=new JLabel("Clave:");
	    lblClave.setBounds(10,70,300,30);
	
	    // Añade las etiquetas a la Ventana
	    add(lblUsuario);
	    add(lblClave);
	     
	    // Crea los campos de texto de Usuario y Clave
	    txtUsuario=new JTextField("Capture Usuario:");
	    txtUsuario.setBounds(120,20,300,30);
	    txtClave=new JTextField("Capture Clave:");
	    txtClave.setBounds(120,70,300,30);
	
	    // Añade las etiquetas a la Ventana
	    add(txtUsuario);
	    add(txtClave);
	
	    // Crea la Etiqueta del Comentario
	    lblComentarios=new JLabel("Comentarios:");
	    lblComentarios.setBounds(10,120,300,30);
	    add(lblComentarios);
	    
	    // Añade el área de Texto; puede agregar texto en el constructor
	    txtArea1=new JTextArea(" Agregar texto");
		txtArea1.setBounds(10,150,410,320); // x,y,ancho,alto
		
		// Agrega texto
		txtArea1.setText("Captura tus comentarios");
		
		// Lo hace no editable; Esto puede usarse en otros controles
		txtArea1.setEditable(true);	
	
		// Le coloca un borde
		txtArea1.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));

		// Agrega el área de Texto al Jframe 
	    add(txtArea1);
	    
	    // Establecemos el Color
	    txtArea1.setForeground(Color.BLUE);
	    txtArea1.setBackground(Color.GRAY);
	    
	    // Editable los JText
	    txtUsuario.setEditable(false);
	    
	    // El Borde del JText
	    txtUsuario.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));	    
	   		 
	 }
}

public class c04_JTextArea_Area_de_Texto {

	public static void main(String[] args) 
	{
        // Clase 04 - JTextArea
        // Un Área de Texto, es un control que permite al usuario capturar datos
		// que tienen una longitud bastante mayor y en el cual se pueden utilizar
		// mas de una línea de escritura de datos; por lo cual se permite
		// el cambio de linea en el texto.
    	// La Clase que se utiliza para crear un campo de Texto es JTextArea
				
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowTextArea xWindow = new myWindowTextArea();

    	//Establecemos la posición (100,100) y el tamaño (430,500) de la Ventana
    	xWindow.setBounds(100,100,440,500);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	//La maximiza
    	//xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }
}
