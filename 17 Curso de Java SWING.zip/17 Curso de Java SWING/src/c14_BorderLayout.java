import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

//Definimos nuestra propia clase de Ventana
class myWindowBorderLayout extends JFrame
{
	// Controles a agregar a la Forma
	Label  lblNorte =  new Label("Norte");
	Label  lblNorte2=  new Label("Norte2");
	Label  lblSur =    new Label("Sur"); 
	Label  lblEste =   new Label("Este"); 
	Label  lblOeste =  new Label("Oeste");	
	Button btnCentro = new Button("CENTRO");     
	 
	// Constructor
	public myWindowBorderLayout() 	
	{
		
		
		// Establece el T�tulo de la Clase
		super("Clase 42_BorderLayout");
		
		// Coloca el BorderLayout
		setLayout(new BorderLayout());

		// A�ade la etiqueta Norte
		add(lblNorte,BorderLayout.NORTH);
		// La siguiente inserci�n encima la anterior
		//add(lblNorte2,BorderLayout.NORTH);
		
		// A�ade la etiqueta al Sur
		add(lblSur,BorderLayout.SOUTH); 
		
		// A�ade la etiqueta ESTE
		add(lblEste,BorderLayout.EAST); 
		
		// A�ade la Etiqueta Oeste
		add(lblOeste,BorderLayout.WEST); 
		
		// A�ade el Bot�n al Centro
		add(btnCentro,BorderLayout.CENTER);
		
		// Usar la siguiente instrucci�n en caso de no haber indicado el tam�o de la
		// ventana, para que se realice el ajuste de acuerdo al Layout
		pack(); 
		
		
		// Lo hace visible
		this.setVisible(true);        
		 
	 }

}

public class c14_BorderLayout {
	public static void main(String[] args) {
        // Clase 42 - BorderLayout
		
		// Los Layouts son formas predefinidas de organizar la posici�n de los controles
		// dentro una forma 
		// Cuando se utilizan los Layouts, JAVA ignora la propiedad de posicionamiento
		// del control, y solamente se permite indicar cual va primero, despues, arriba,
		// abajo, a la izquierda etc. En este curso veremos los Layouts mas importantes
		// de java.
		
		// Para esta clase veremos el BorderLayout, el cual permite organizar los controles
		// de acuerdo a posiciones: CENTER, NORTH, SOUTH, EAST, WEST.
		// La Clase que utiliza es BorderLayout

		// Creamos el Objeto de la Forma
    	myWindowBorderLayout xWindow = new myWindowBorderLayout();


    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	// Define el Tama�o
    	//xWindow.setSize(400, 400);
    	
    	//La maximiza
    	//xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }


}
