import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

//Definimos nuestra propia clase de Ventana
class myWindowList extends JFrame
{
	 // Para la etiqueta de los lenguajes
	 private JLabel lblLenguajes;
	 
	 // Scroll Panel
	 private JScrollPane pnlLenguajes;
	 
	 // Vector para Cadenas
	 private String strLenguajes[];
	 
	 // El JList
	 private JList lstLenguajes;
	 
	 // ListModel para usar con el JList
	 private DefaultListModel dlmLenguajes = new DefaultListModel();
	
	 // El Constructor
	 public myWindowList() 
	 {
	 	// Coloca el Titulo
	 	setTitle("Clase 07 JList");
		
	    // Establece la acción a realizar cuando se cierra la forma
	 	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 	 	
	  	// Establece que no existe un Layout
	    setLayout(null);
	      
	    
	    // Etiqueta para el JList
	    lblLenguajes=new JLabel("Lenguajes:");
	    lblLenguajes.setBounds(10,10,300,30);
	    
	    // Prepara el vector para agregar los elementos al JList
	    strLenguajes = new String[5];
	    strLenguajes[0]="Java";
	    strLenguajes[1]="C++";
	    strLenguajes[2]="VBNet";
	    strLenguajes[3]="VC#";
	    strLenguajes[4]="VC++";
	    
	    // Crea el JList con los elementos del Vector
	    lstLenguajes = new JList(strLenguajes);
	    lstLenguajes.setBounds(100,320,320,120);
	    
//	    strLenguajes = new String[7];
//	    strLenguajes[0]="Java";
//	    strLenguajes[1]="C++";
//	    strLenguajes[2]="VBNet";
//	    strLenguajes[3]="VC#";
//	    strLenguajes[4]="VC++";
//	    strLenguajes[5]="Pascal";
//	    strLenguajes[6]="Fortran";
//	    
//	    // Establece la Nueva Lista
//	    lstLenguajes.setListData(strLenguajes);
	    
	    
	    
	    // Añade los Lenguajes al Panel
	    pnlLenguajes = new JScrollPane(lstLenguajes);
	    
	    // Define el tamaño del Panle
	    pnlLenguajes.setBounds(100,10,320,120);
	    
	    // Los añade a la forma
	    add(pnlLenguajes);
	    add(lblLenguajes);
	   
	    // Agrega elementos al JList desde un Modelo
	    dlmLenguajes.addElement("Php");
		dlmLenguajes.addElement("Asp");
		dlmLenguajes.addElement("JavaScript");
		lstLenguajes.setModel(dlmLenguajes);
		dlmLenguajes.addElement("Html");
		dlmLenguajes.addElement("CSS");
	    dlmLenguajes.addElement("Java");
	    dlmLenguajes.addElement("Fortran");
	    dlmLenguajes.addElement("Pascal");
	    dlmLenguajes.addElement("Java");
	    
	     // Selecciona la posición 0
	    lstLenguajes.setSelectedIndex(0);
	    
	    // Establece un Borde
	    //lstLenguajes.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	    
	    // Elementos en el List
	    System.out.println("Elementos:"+dlmLenguajes.size());
	    	    
	    // Agrega un Elemento en una posición específica
	    dlmLenguajes.insertElementAt("Pos 1", 1);
	    dlmLenguajes.add(5,"Pos 5");
	    
	    // Obtiene un Elemento en una posición espefíca
	    System.out.println("Elemento en posición 3:"+dlmLenguajes.getElementAt(3));

	    // Encontrar un Elemento
	    System.out.println("Encontro Asp en:"+dlmLenguajes.indexOf("Asp"));
	    System.out.println("Encontro Java en:"+dlmLenguajes.lastIndexOf("Java"));
	    
	    // Elimina un elemento 
	    dlmLenguajes.remove(0);
	    dlmLenguajes.removeElement("Java");
	    
	    
	    // Elimina todos los Elementos	    
	    //dlmLenguajes.clear();
	    //dlmLenguajes.removeAllElements();
		 
	 }

}

public class c07_JList 
{
	public static void main(String[] args) 
	{
        // Clase 07 - JList
		
		// Un JList es una lista de datos con una dimensión para su visualización
		// específica, de la cual es posible seleccionar una o mas opciones; su 
		// diferencia principal con respecto al ComboBox
		
		// La Clase que permite crear estos controles es la clase JList
		
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowList xWindow = new myWindowList();

    	//Establecemos la posición (100,100) y el tamaño (500,500) de la Ventana
    	xWindow.setBounds(100,100,500,150);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);
	
    }
}
