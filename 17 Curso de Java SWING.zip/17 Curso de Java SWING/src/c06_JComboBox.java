import java.awt.Color;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

//Definimos nuestra propia clase de Ventana
class myWindowComboBox extends JFrame
{
	private JLabel lblUsuario,lblClave,lblComentarios,lblHost;
	private JTextField txtUsuario, txtClave;
	private JScrollPane pnlComentarios;
	JTextArea txtArea1;
	JComboBox cboHost;
	
	
 public myWindowComboBox() 
 {
 	// Coloca el Titulo
 	setTitle("Clase 06 JComboBox");
	
    // Establece la acción a realizar cuando se cierra la forma
 	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 	 	
  	// Establece que no existe un Layout
    setLayout(null);
      
    // Crea las Etiquetas de Usuario y Clave
    lblUsuario=new JLabel("Usuario:");
    lblUsuario.setBounds(10,20,300,30);
    lblClave=new JLabel("Clave:");
    lblClave.setBounds(10,70,300,30);

    // Añade las etiquetas a la Ventana
    add(lblUsuario);
    add(lblClave);
      
    // Crea los campos de texto de Usuario y Clave
    txtUsuario=new JTextField("Capture Usuario:");
    txtUsuario.setBounds(120,20,300,30);
    txtClave=new JTextField("Capture Clave:");
    txtClave.setBounds(120,70,300,30);

    // Añade las etiquetas a la Ventana
    add(txtUsuario);
    add(txtClave);

    // Crea la Etiqueta del Comentario
    lblComentarios=new JLabel("Comentarios:");
    lblComentarios.setBounds(10,120,300,30);
    add(lblComentarios);

    // Crea el área de Texto
    txtArea1=new JTextArea();
 	txtArea1.setBounds(10,150,410,300);
 	// Lo hace no editable; Esto puede usarse en otros controles
 	//txtArea1.setEditable(false);	
 	// Le coloca un borde
 	//txtArea1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

 	// Crea al Panel de Control y al mismo tiempo agrega el area de texto
    pnlComentarios=new JScrollPane(txtArea1);    
    pnlComentarios.setBounds(10,150,410,300);
    add(pnlComentarios);    
    
    // Etiqueta para el cboBox
    lblHost=new JLabel("Host:");
    lblHost.setBounds(10,455,300,30);
    
    cboHost = new JComboBox();
    cboHost.setBounds(50,460,180,20);
    add(cboHost);
    add(lblHost);
    cboHost.addItem("localhost");
    cboHost.addItem("192.92.98.32");
    cboHost.addItem("www.sitioweb.com");
        
    // Desselecciona
    cboHost.setSelectedIndex(-1);
	cboHost.removeItemAt(0);
	
    // Color
    //cboHost.setForeground(Color.BLUE);
    //cboHost.setBackground(Color.GRAY);
    
    // Visible
    //cboHost.setVisible(false);
    //cboHost.enable(false);
	
	// Le coloca un borde
	cboHost.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		

 }

}

public class c06_JComboBox {
	public static void main(String[] args) {
        // Clase 06 - JComboBox
		
		// Un ComboBox es un control que permite colocar una colección de datos
		// los cuales son mostrados en una ventana popup descendente, para que el
		// usuario pueda seleccionar uno de los datos de la colección.
		
		// La Clase que permite crear estos controles es la clase JComboBox
		
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowComboBox xWindow = new myWindowComboBox();

    	//Establecemos la posición (100,100) y el tamaño (440,500) de la Ventana
    	xWindow.setBounds(100,100,440,500);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);
    	
    }
}
