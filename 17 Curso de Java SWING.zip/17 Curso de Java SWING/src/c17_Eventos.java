import java.awt.GridLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

//Definimos nuestra propia clase de Ventana
class myWindowEvent extends JFrame
{
	// Controles a agregar a la Forma
	Button     btnAceptar   =  new Button("Aceptar");
	 
	// Constructor
	public myWindowEvent() 	
	{
		
		
		// Establece el Título de la Clase
		super("Clase 45_Eventos");

		// Establece el Layout
		setLayout(null);
		
		
		// Establece posición y tamaño
		btnAceptar.setBounds(10, 10, 120, 25);
	
		// Establece el Evento a Escuchar
		btnAceptar.addActionListener(new classBtnAceptarListener());
		
		
		
		// Agrega el Bot�n a la Forma
		add(btnAceptar);
		
		
	 }
	
	
}



// La Clase para ActionListener
class classBtnAceptarListener implements ActionListener
{
	private int contador=1;
	public void actionPerformed(ActionEvent e)
	{
		System.out.println("El bot�n ha sido pulsado"+contador+" veces\r\n");
		contador++;
	}
}

public class c17_Eventos {
	public static void main(String[] args) {
        
		// Clase 45 - Eventos
		
		// Un evento es un "suceso" o "algo" que puede pasarle a un objeto
		// de los ya visto en el curso. Por ejemplo, al objeto button, le
		// puede suceder que el usuario lo presione con el mouse; a un objeto
		// JTextField, puede sucederle que el usuario est� capturando 
		// informaci� en el.
		
		// JAVA realiza el Manejo de EVENTOS a trav�s de Clases, las cuales
		// est�n clasificadas de acuerdo a los Eventos y Objetos.
		
		// Para hacer que un objeto pueda controlar este tipo de eventos de 
		// tenemos que invocar el m�todo:
		// public addActionListener(ClaseControlaEvento)
		
		// Las Clases de la cuales dispone Java para el manejo de eventos,son
		// las siguientes:
		
		// ActionListener. Esta clase se utiliza cuando se desean capturar
		// eventos de tipo ActionEvent; como por ejemplo pulsar el bot�n del
		// mouse. El m�todo que debe de implementarse en esta clase es:
		// public void actionPerformed(ActionEvent e)
		
		// ItemListener. Es utilizada para controlar los eventos de los 
		// objetos JCheckbox, JList y JCheckboxMenuItem. El m�todo que 
		// deberemos implementar es:
		// public void itemStateChanged(ItemEvent e)
		
		// WindowListener. Esta clase se utiliza cuando se quiere implementar
		// el control de Eventos de tipo WindowEvent. Los productores de estos 
		// eventos son los objetos de tipo JDialog y JFrame. Podemos asociar
		// el control del evento a trav�s del m�todo: 
		// public void addWindowListener(WindowListener w)
		
		// Los m�todos que deber�n de implementarse son:
		// public void windowOpened(WindowEvent e) 
		// detecta que la ventana ha sido abierta;
		
		// public void windowActivated(WindowEvent e)
		// detecta que la ventana ha sido activada;
		
		// public void windowDeactivated(WindowEvent e)
		// detecta que la ventana ha sido desactivada;

		// public void windowIconified(WindowEvent e) 
		// detecta que la ventana ha sido iconificada (minimizada);
		
		// public void windowClosed(WindowEvent e)
		// detecta que la ventana ha sido cerrada (este evento se
		// produce cuando se hace una llamada al m�todo dispose() 
		// sobre la ventana;
		
		// public void windowDeiconified(WindowEvent e)
		// detecta que la ventana ha sido desiconificada (maximizada o restaurada);
		
		// public void windowClosing(WindowEvent e)
		// detecta que se ha pulsado el bot�n de cerrar la ventana.
		
		// ComponentListener.Para marcar un objeto con la capacidad de escuchar 
		// eventos de tipo ComponentEvent deberemos implementar la clase ComponentListener. 
		// Los objetos que producen estos eventos son los JDialog y los	JFrames.
		// Para a�adir a un productor de eventos un oyente de sus eventos 
		// invocaremos el m�todo:
		// public void addComponentListener(ComponentListener c)
		
		// Los m�todos que debemos definir al implementar esta interfaz son:
		// public void componentResized(ComponentEvent e)
		// public void componentMoved(ComponentEvent e)
		// public void componentShown(ComponentEvent e)
		// public void componentHidden(ComponentEvent e)
		
		// AdjustmentListener. Para escuchar los eventos de tipo AdjustmentEvent 
		// producidos por la clase JScrollbar deberemos implementar la clase
		// AdjustmentListener. Para utilizarla deberemos invocar la operaci�n:
		// public void addAdjustmentListener(AdjustementListener adj)
		
		// El m�todo que debemos implementar para capturar el evento es
		// public void adjustmentValueChaged(AdjustementEvent e)

		// MouseListener. Como su nombre indica esta interfaz nos permitir� 
		// controlar los eventos de tipo MouseEvent, que son los producidos 
		// por el rat�n al interaccionar con cualquiera de las clases Canvas, 
		// JDialog, JFrame, JPanel y Jwindow.
		
		// Para a�adir a cualquiera de estas clases un oyente de eventos 
		// deberemos invocar al m�todo
		// public void addMouseListener(MouseListener ml)
		
		// Los m�todos que vienen definidos son:
		// public void mouseClicked(mouseEvent e)
	    // public void mousePresed(mouseEvent e)
	    // public void mouseReleased(mouseEvent e)
		// public void mouseEntered(mouseEvent e)
		// public void mouseExited(mouseEvent e)
		
		// MouseMotionListener. Cualquiera de los objetos de las clases Canvas,
		// JDialog, JFrame, JPanel y Jwindow pueden producir eventos de este 
		// tipo. Para que un objeto puede escuchar este tipo de eventos deber�
		// utilizar el M�todo:		
		// public void addMouseMotionListener(MouseMotionListener ml)
		
		// Los m�todos de esta interfaz son:
	    // public void mouseDragged(MouseEvent e)
	    // public void mouseMoved(MouseEvent e)
		
		// FocusListener. Cuando un componente recibe el foco, es decir, es el
		// elemento de la pantalla que est� activo se producen eventos de tipo 
		// FocusEvent. Para hacer que un objeto pueda escuchar eventos de tipo 
		// FocusEvent deber� implementar la interfaz FocusListener, y adem�s
		// deber� ser a�adido como FocusListener con el m�todo:
		// public void addFocusListener(FocusListener fl)
		
		// Los m�todos disponibles son:
		// public void focusGained(FocusEvent e)
		// public void foculsLost(FocusEvent e)
		
		
		// KeyListener. Con la interfaz KeyListener seremos capaces de detectar
		// y tratar los eventos generados por la pulsaci�n de una tecla o por 
		// combinaciones de ellas, los KeyEvent. Los gestores que implementan 
		// esta interfaz s�lo pueden a�adirse a aquellos componentes de la GUI
		// que son capaces de recibir el foco del teclado.
		// El m�todo para asignar el control de la clase es:
		// public void addKyListener(KeyListener kl)
		
		// Esta clase KeyListener define tres m�todos que deben ser redefinidos
		// en el gestor que la implemente y que son:
		// public void keyTyped(KeyEvent e)
		// public void keyPressed(KeyEventt e)
		// public void keyReleased(KeyEvent e)
		
		
		
		
		
		
		// Creamos el Objeto de la Forma
    	myWindowEvent xWindow = new myWindowEvent();
    	
    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	// Define el Tama�o
    	xWindow.setSize(400, 400);
    	
    	//La maximiza
    	//xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    	
    }


}
