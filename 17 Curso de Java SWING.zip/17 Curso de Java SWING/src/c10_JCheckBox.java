import java.awt.Frame;
import javax.swing.JCheckBox;
import javax.swing.JFrame;

//Definimos nuestra propia clase de Ventana
class myWindowCheckBox extends JFrame
{
	// Declara variables de JCheckBox
	private JCheckBox chkBitacora,chkMensajes;
		
	// Constructor
	public myWindowCheckBox() 	
	{
		// Prepara y Agrega el CheckBox 
		chkBitacora=new JCheckBox("Grabar en la Bitácora");
        chkBitacora.setBounds(10,10,180,30);
        //chkBitacora.setEnabled(false);
        add(chkBitacora);

        // Prepara y Agregao el checkbox
        chkMensajes=new JCheckBox("Mensajes de éxito");
        chkMensajes.setBounds(10,50,180,30);
        chkMensajes.setLabel("Modificando");
        chkMensajes.setSelected(true);
        add(chkMensajes);

	 	// Coloca el Titulo
	 	setTitle("Clase10_JCheckBox");
	 			
	    // Establece la acción a realizar cuando se cierra la forma
	 	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 		 	
	  	// Establece que no existe un Layout
	    setLayout(null);
		 
	 }

}

public class c10_JCheckBox {
	public static void main(String[] args) 
	{
        // Clase 10 - JCheckBox
		
		// Este control nos permite Activar o Desactivar una casilla para
		// de esta forma indicar si se utiliza o no cierta información.
		// Es posible seleccionar mas de uno de ellos.		
		// La Clase que permite crear estos controles es la clase JCheckBox
		
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowCheckBox xWindow = new myWindowCheckBox();

    	// Establecemos la posición (100,100) y el tamaño (430,500) de la Ventana
    	xWindow.setBounds(100,100,440,500);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);

    	//La maximiza
    	xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
    }
}