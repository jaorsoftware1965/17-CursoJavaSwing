import java.awt.Frame;
import javax.swing.JFrame;
import javax.swing.JLabel;

// Definimos nuestra propia clase de Ventana
class myWindowLabel extends JFrame
{
	// Definiendo objetos de etiquetas
	private JLabel label1,label2;
	
    public myWindowLabel() 
    {
    	// Coloca el Titulo
    	setTitle("Clase 02 JLabel Etiquetas");
	
    	// Establece la Operación a realizarse al cerrar la ventana
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Establece la posición y tamaño de la Ventana
		setBounds(100, 100, 450, 300);// x,y,ancho, alto

    	// Establece que no existe un Layout para Controlar el posicionamiento de
    	// de los elementos. 
        setLayout(null);
        
        // Crea la Primera etiqueta
        label1=new JLabel("Mi Primera Etiqueta.");
        
        // Establece su posición y tamaño
        label1.setBounds(10,20,300,30); // x,y,ancho, alto
        
        // Añade la etiqueta a la Ventana
        add(label1);
        
        // Crea la Segunda Etiqueta
        label2=new JLabel("Mi Segunda Etiqueta.");
        
        // Establece su posición y tamaño
        label2.setBounds(10,100,300,30);
        
        // Añade la etiqueta a la Ventana
        add(label2);
        
        // la hace visible
        setVisible(true);
        
    }

}

public class c02_JLabel_Etiquetas {

    public static void main(String[] args) {
        // Clase 02 - JLabel_Etiquetas
    	//            Layouts. Formas predefinidas de organizar controles dentro de otro
    	
        // Una etiqueta es un control que permite desplegar un mensaje de texto; el cual
    	// puede ser configurado de muchas formas: color, fuente, tamaño; etc.
    	// Las etiquetas son principalmente utilizadas para indicar que información debe
    	// de capturar un usuario y por lo regular se utilizan en conjunto con el elemento
    	// JTextField y JTextArea; aunque puede estar relacionado con cualquier otro
    	// elemento de captura.
        // La Clase que se utiliza para crear una etiqueta es JLabel
    	// Métodos a utilizar
    	// SetBounds. Establece tamaño y posición
        
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowLabel xWindow = new myWindowLabel();

    	//Establecemos la posición y el tamaño
    	xWindow.setBounds(250,150,300,300); //x,y,ancho,alto

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
        // No funciona porque esta como no dimensionable
        //xWindow.setExtendedState(Frame.MAXIMIZED_BOTH);
        // Podemos usar el valor 6 en lugar de Frame.MAXIMIZED_BOTH, 
        // averiguado en la siguiente linea y así evitar la carga
        // de la libreria awt
        
        // Imprimimos el valor de la constante
        System.out.println("->"+Frame.MAXIMIZED_BOTH);
    	
    	// Declaramos una etiqueta
    	JLabel xEtiqueta = new JLabel("Tercera Etiqueta");
    	
    	// Definimos posición y tamaño
    	xEtiqueta.setBounds(10, 180, 150, 50); // x,y,ancho,alto
    	
    	// Agregamos la etiqueta a la ventana
    	xWindow.add(xEtiqueta);
    	
    }

}
