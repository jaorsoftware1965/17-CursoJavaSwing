import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

//Definimos nuestra propia clase de Ventana
class myWindowTextField extends JFrame
{
     // Elementos Privados
	 private JLabel     lblUsuario, lblClave;
	 private JTextField txtUsuario, txtClave;
	
	 // Constructor de la Clase
	 public myWindowTextField() 
	 {
	 	// Coloca el Titulo
	 	setTitle("Clase 03 JTextField Campo de Texto");
		
	 	// Establece la acción a realizar cuando se cierra la forma
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
	 	// Establece que no existe un Layout
	    setLayout(null);
	     
	    // Crea las Etiquetas de Usuario y Clave
	    lblUsuario=new JLabel("Usuario:");
	    lblUsuario.setBounds(10,20,300,30);
	    lblClave=new JLabel("Clave:");
	    lblClave.setBounds(10,70,300,30);
	
	    // Añade las etiquetas a la Ventana
	    add(lblUsuario);
	    add(lblClave);
	     
	    // Crea los campos de texto de Usuario y Clave
	    txtUsuario=new JTextField("Capture Usuario:");
	    txtUsuario.setBounds(120,20,300,30);
	    txtClave=new JTextField("Capture Clave:");
	    txtClave.setBounds(120,70,300,30);
	
	    // Añade las etiquetas a la Ventana
	    add(txtUsuario);
	    add(txtClave);
	    	 
	    // Establezco el texto
	    txtUsuario.setText("User");
	    txtClave.setText("Pass");
	    
	    // Establezco el Color
	    txtUsuario.setForeground(Color.BLUE);
	    txtClave.setBackground(Color.RED);
	    
	    // Creamos una nueva fuente
        Font font = new Font("Courier", Font.ITALIC | Font.BOLD,14);

        // Establezco la Fuente
	    txtUsuario.setFont(font);
	    txtClave.setFont(font);
	    
	 }

}

// Clase Principal
public class c03_JTextField_Campo_Texto 
{

	// Función main
	public static void main(String[] args) 
	{
        // Clase 03 - JTextField Campo  de Texto
        // Un campo de texto, es un control que permite al usuario capturar datos
		// desde su teclado. Es el control de datos de entrada por excelencia.
    	// Al igual que el JLabel, puede ser configurado de muchas formas: color, 
		// fuente, tamaño; etc.
    	// La Clase que se utiliza para crear un campo de Texto es JTextField
				
        // Declaramos un objeto de nuestra Clase myWindow        
    	myWindowTextField xWindow = new myWindowTextField();

    	//Establecemos la posición y el tamaño de la Ventana
    	xWindow.setBounds(100,100,500,500);

    	//Evitamos que sea redimensionable 
    	xWindow.setResizable(false);
    	
    	//La hacemos visible
    	xWindow.setVisible(true);
    	
    }

}
